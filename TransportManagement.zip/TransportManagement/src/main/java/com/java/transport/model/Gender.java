package com.java.transport.model;

public enum Gender {
	MALE,FEMALE

}
